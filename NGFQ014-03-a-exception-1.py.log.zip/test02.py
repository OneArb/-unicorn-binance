import math

digit_precision = 4

number = [430, 1, 100, 10, 1250, 125000, 0.055426, 0.0123456, 0.00123456]

def make_format(price):

    if price > 0:
        precision = int(digit_precision-math.log10(price))
        if precision <= 0:
            precision = 2
        # fformat = '%.' + str(precision) + 'f'
        fformat = '{:.' + str(precision) + 'f}'

        format_price = fformat.format(price)
        # print(fformat.format(price))
        print(format_price.rjust(15, ' '))

def calc_precision(price):

    if price:

        digit_precision = 4

        precision = digit_precision - int(math.log10(price))

        if precision <= 1:
            precision = 2

        return precision

# for n in number:
#     print(n, calc_precision(n), end=' - ')
#     make_format(float(n))


myfloat = 5.666
myformat = "%.9f"
# myfloatstr = "%.2f".format(myfloat)
myfloatstr = myformat % myfloat
print(myfloat)
# print("%.9f" % myfloat)
# print("{:.9f}".format(myfloat))
# error_msg: sent 1011 (unexpected error) keepalive ping timeout; no close frame received

myint = 156
print(str(myint).rjust(2))

import os
print(os.path.basename(__file__))

#
# # A function that returns the length of the value:
# def myFunc(e):
#     return len(e)
#
#
# cars = ['Ford', 'Mitsubishi', 'BMW', 'VW']
#
# cars.sort()
#
# print(cars)


# hours = 5
# minutes = 2
# seconds = 25
# time = "{:02}:{:02}:{:02} {}".format(hours, minutes, seconds, "pm" if hours > 12 else "am")
# print(time)


myfloat = 0.05556

precision = 5
format = ':.' + str(precision) + 'f'
# print("{format}".format(myfloat))

# print("{:.5f}".format(myfloat))


# import decimal
#
# width = 10
# precision = 2
#
# myfloat = 1525556.66
# value = decimal.Decimal(str(myfloat))
# # value = decimal.Decimal("12.34567")
# # mystr = f"{value:{width}.{precision}}"  # nested fields
# mystr = (f"{value:20.{precision}}")  # .lstrip()  # nested fields
# # Dmg.lsymbol_precision[ts]
# print(mystr)
#
# print("{:.8f}".format(myfloat))



# a = decimal.Decimal
# print(dir(a))
# print(a.__dict__)

# for o in a.__dict__:
#         print(o)

# print(getcontext())


import logging
import os
filename = os.path.basename(__file__) + '.log'
print(filename)

# https://docs.python.org/3/library/logging.html#logging-levels
logging.basicConfig(level=logging.DEBUG,
                    filename=os.path.basename(__file__) + '.log',
                    format="{asctime} [{levelname:8}] {process} {thread} {module}: {message}",
                    # mode='a',
                    force=True,
                    style="{")

# logging.basicConfig(format='%(process)d-%(levelname)s-%(message)s', force=True)

logging.warning('Test log entry')


#
# import logging
# logger = logging.getLogger()
# fhandler = logging.FileHandler(filename=os.path.basename(__file__) + '.log', mode='a')
# formatter = logging.Formatter("{asctime} [{levelname:8}] {process} {thread} {module}: {message}")
# style="{"
# fhandler.setFormatter(formatter)
# logger.addHandler(fhandler)
# logger.setLevel(logging.DEBUG)

# logger.warning('Test log entry')